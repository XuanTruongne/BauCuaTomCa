﻿namespace BAUCUATOMCA
{
    public partial class Form2 : Form
    {
        private readonly Form1 mainForm;

        // Constructor nhận Form1
        public Form2(Form1 form)
        {
            InitializeComponent();
            mainForm = form;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // Lấy tiền từ Form1 đang chạy
            label2.Text = mainForm.money(); // hoặc mainForm.TienHienTai.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int doitien = int.Parse(label2.Text.Replace(",", "").Replace(" VNĐ", ""));

            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Vui lòng chọn tiền!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (doitien > 25000)
                {
                    Form4 frm = new Form4();
                    frm.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Bạn không đủ tiền!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void comboBox1_KeyDown(object sender, KeyEventArgs e)
        {
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
        }
    }
}
