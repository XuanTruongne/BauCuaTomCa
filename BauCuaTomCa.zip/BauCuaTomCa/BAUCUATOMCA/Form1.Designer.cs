﻿namespace BAUCUATOMCA
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label1 = new Label();
            chon = new ComboBox();
            label2 = new Label();
            tienCuoc = new ComboBox();
            button1 = new Button();
            groupBox1 = new GroupBox();
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            TienHienTai = new Label();
            groupBox2 = new GroupBox();
            label4 = new Label();
            label3 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            pictureBox4 = new PictureBox();
            cb_ca = new CheckBox();
            cb_cua = new CheckBox();
            cb_tom = new CheckBox();
            cb_ga = new CheckBox();
            cb_bau = new CheckBox();
            cb_nai = new CheckBox();
            naptien = new Button();
            checkBox7 = new CheckBox();
            button2 = new Button();
            button4 = new Button();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            button5 = new Button();
            listBox1 = new ListBox();
            label8 = new Label();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(948, 70);
            label1.Name = "label1";
            label1.Size = new Size(57, 22);
            label1.TabIndex = 2;
            label1.Text = "Chọn";
            // 
            // chon
            // 
            chon.BackColor = Color.WhiteSmoke;
            chon.DropDownStyle = ComboBoxStyle.DropDownList;
            chon.FormattingEnabled = true;
            chon.Items.AddRange(new object[] { "Nai", "Bầu", "Gà", "Cá", "Cua", "Tôm" });
            chon.Location = new Point(948, 100);
            chon.Name = "chon";
            chon.Size = new Size(233, 28);
            chon.TabIndex = 3;
            chon.KeyPress += chon_KeyPress;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(948, 164);
            label2.Name = "label2";
            label2.Size = new Size(98, 22);
            label2.TabIndex = 2;
            label2.Text = "Tiền cược";
            // 
            // tienCuoc
            // 
            tienCuoc.FormattingEnabled = true;
            tienCuoc.Items.AddRange(new object[] { "2", "5", "10", "20", "50", "100", "200", "500", "1000", "5000" });
            tienCuoc.Location = new Point(948, 194);
            tienCuoc.Name = "tienCuoc";
            tienCuoc.Size = new Size(233, 28);
            tienCuoc.TabIndex = 3;
            tienCuoc.SelectedIndexChanged += tienCuoc_SelectedIndexChanged;
            tienCuoc.KeyPress += tienCuoc_KeyPress;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(255, 128, 128);
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point);
            button1.ForeColor = Color.SeaShell;
            button1.Location = new Point(1012, 346);
            button1.Name = "button1";
            button1.Size = new Size(141, 68);
            button1.TabIndex = 4;
            button1.Text = "SPIN";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(pictureBox3);
            groupBox1.Controls.Add(pictureBox2);
            groupBox1.Controls.Add(pictureBox1);
            groupBox1.Font = new Font("Microsoft Sans Serif", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            groupBox1.Location = new Point(371, 429);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(541, 204);
            groupBox1.TabIndex = 5;
            groupBox1.TabStop = false;
            groupBox1.Text = "Result";
            // 
            // pictureBox3
            // 
            pictureBox3.ErrorImage = (Image)resources.GetObject("pictureBox3.ErrorImage");
            pictureBox3.Image = Properties.Resources._6;
            pictureBox3.Location = new Point(383, 40);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(122, 128);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 0;
            pictureBox3.TabStop = false;
            pictureBox3.Visible = false;
            // 
            // pictureBox2
            // 
            pictureBox2.ErrorImage = (Image)resources.GetObject("pictureBox2.ErrorImage");
            pictureBox2.Image = Properties.Resources._2;
            pictureBox2.Location = new Point(224, 40);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(122, 128);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            pictureBox2.Visible = false;
            // 
            // pictureBox1
            // 
            pictureBox1.ErrorImage = (Image)resources.GetObject("pictureBox1.ErrorImage");
            pictureBox1.Image = Properties.Resources._1;
            pictureBox1.Location = new Point(59, 40);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(122, 128);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Visible = false;
            // 
            // TienHienTai
            // 
            TienHienTai.AutoSize = true;
            TienHienTai.BackColor = SystemColors.ActiveCaption;
            TienHienTai.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            TienHienTai.Location = new Point(60, 33);
            TienHienTai.Name = "TienHienTai";
            TienHienTai.Size = new Size(72, 28);
            TienHienTai.TabIndex = 6;
            TienHienTai.Text = "10000";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(TienHienTai);
            groupBox2.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox2.Location = new Point(969, 466);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(204, 71);
            groupBox2.TabIndex = 7;
            groupBox2.TabStop = false;
            groupBox2.Text = "Tiền hiện tại";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 15F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(584, 390);
            label4.Name = "label4";
            label4.Size = new Size(28, 29);
            label4.TabIndex = 2;
            label4.Text = "0";
            label4.Visible = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 15F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(237, 244);
            label3.Name = "label3";
            label3.Size = new Size(28, 29);
            label3.TabIndex = 2;
            label3.Text = "0";
            label3.Visible = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 15F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(46, 244);
            label5.Name = "label5";
            label5.Size = new Size(184, 29);
            label5.TabIndex = 2;
            label5.Text = "Tiền xơi được:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(1062, 12);
            label6.Name = "label6";
            label6.Size = new Size(116, 22);
            label6.TabIndex = 2;
            label6.Text = "Số lần chơi:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label7.Location = new Point(1179, 12);
            label7.Name = "label7";
            label7.Size = new Size(21, 22);
            label7.TabIndex = 2;
            label7.Text = "0";
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(371, 47);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(541, 310);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 1;
            pictureBox4.TabStop = false;
            // 
            // cb_ca
            // 
            cb_ca.AutoSize = true;
            cb_ca.Font = new Font("Segoe UI", 48F, FontStyle.Bold, GraphicsUnit.Point);
            cb_ca.Location = new Point(513, 327);
            cb_ca.Name = "cb_ca";
            cb_ca.Size = new Size(18, 17);
            cb_ca.TabIndex = 9;
            cb_ca.UseVisualStyleBackColor = true;
            cb_ca.Visible = false;
            // 
            // cb_cua
            // 
            cb_cua.AutoSize = true;
            cb_cua.Font = new Font("Segoe UI", 48F, FontStyle.Bold, GraphicsUnit.Point);
            cb_cua.Location = new Point(676, 327);
            cb_cua.Name = "cb_cua";
            cb_cua.Size = new Size(18, 17);
            cb_cua.TabIndex = 9;
            cb_cua.UseVisualStyleBackColor = true;
            cb_cua.Visible = false;
            // 
            // cb_tom
            // 
            cb_tom.AutoSize = true;
            cb_tom.Font = new Font("Segoe UI", 48F, FontStyle.Bold, GraphicsUnit.Point);
            cb_tom.Location = new Point(831, 327);
            cb_tom.Name = "cb_tom";
            cb_tom.Size = new Size(18, 17);
            cb_tom.TabIndex = 9;
            cb_tom.UseVisualStyleBackColor = true;
            cb_tom.Visible = false;
            // 
            // cb_ga
            // 
            cb_ga.AutoSize = true;
            cb_ga.Font = new Font("Segoe UI", 48F, FontStyle.Bold, GraphicsUnit.Point);
            cb_ga.Location = new Point(831, 171);
            cb_ga.Name = "cb_ga";
            cb_ga.Size = new Size(18, 17);
            cb_ga.TabIndex = 9;
            cb_ga.UseVisualStyleBackColor = true;
            cb_ga.Visible = false;
            // 
            // cb_bau
            // 
            cb_bau.AutoSize = true;
            cb_bau.Font = new Font("Segoe UI", 48F, FontStyle.Bold, GraphicsUnit.Point);
            cb_bau.Location = new Point(676, 171);
            cb_bau.Name = "cb_bau";
            cb_bau.Size = new Size(18, 17);
            cb_bau.TabIndex = 9;
            cb_bau.UseVisualStyleBackColor = true;
            cb_bau.Visible = false;
            // 
            // cb_nai
            // 
            cb_nai.AutoSize = true;
            cb_nai.Font = new Font("Segoe UI", 48F, FontStyle.Bold, GraphicsUnit.Point);
            cb_nai.Location = new Point(514, 171);
            cb_nai.Name = "cb_nai";
            cb_nai.Size = new Size(18, 17);
            cb_nai.TabIndex = 9;
            cb_nai.UseVisualStyleBackColor = true;
            cb_nai.Visible = false;
            // 
            // naptien
            // 
            naptien.BackColor = Color.CadetBlue;
            naptien.Cursor = Cursors.Hand;
            naptien.FlatStyle = FlatStyle.Flat;
            naptien.Font = new Font("Microsoft Sans Serif", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            naptien.ForeColor = SystemColors.ButtonHighlight;
            naptien.Location = new Point(68, 100);
            naptien.Name = "naptien";
            naptien.Size = new Size(137, 43);
            naptien.TabIndex = 21;
            naptien.Text = "Nạp tiền";
            naptien.UseVisualStyleBackColor = false;
            naptien.Click += naptien_Click;
            // 
            // checkBox7
            // 
            checkBox7.AutoSize = true;
            checkBox7.Location = new Point(1076, 134);
            checkBox7.Name = "checkBox7";
            checkBox7.Size = new Size(105, 24);
            checkBox7.TabIndex = 25;
            checkBox7.Text = "Chọn nhiều";
            checkBox7.UseVisualStyleBackColor = true;
            checkBox7.Visible = false;
            checkBox7.CheckedChanged += checkBox7_CheckedChanged;
            // 
            // button2
            // 
            button2.FlatStyle = FlatStyle.Flat;
            button2.Location = new Point(948, 228);
            button2.Name = "button2";
            button2.Size = new Size(94, 34);
            button2.TabIndex = 27;
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.MediumVioletRed;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            button4.ForeColor = Color.LavenderBlush;
            button4.Location = new Point(1100, 597);
            button4.Name = "button4";
            button4.Size = new Size(105, 36);
            button4.TabIndex = 29;
            button4.Text = "Đổi card";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.LightSlateGray;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            button5.ForeColor = Color.LavenderBlush;
            button5.Location = new Point(1087, 228);
            button5.Name = "button5";
            button5.Size = new Size(94, 35);
            button5.TabIndex = 30;
            button5.Text = "ALL IN";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // listBox1
            // 
            listBox1.BackColor = SystemColors.ButtonFace;
            listBox1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 20;
            listBox1.Location = new Point(12, 429);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(346, 204);
            listBox1.Sorted = true;
            listBox1.TabIndex = 24;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 15F, FontStyle.Bold, GraphicsUnit.Point);
            label8.Location = new Point(118, 379);
            label8.Name = "label8";
            label8.Size = new Size(99, 29);
            label8.TabIndex = 2;
            label8.Text = "History";
            label8.Visible = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(1224, 678);
            Controls.Add(listBox1);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button2);
            Controls.Add(naptien);
            Controls.Add(checkBox7);
            Controls.Add(cb_tom);
            Controls.Add(cb_cua);
            Controls.Add(cb_ca);
            Controls.Add(cb_ga);
            Controls.Add(cb_bau);
            Controls.Add(cb_nai);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(button1);
            Controls.Add(tienCuoc);
            Controls.Add(label2);
            Controls.Add(chon);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label8);
            Controls.Add(label4);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label1);
            Controls.Add(pictureBox4);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "BẦU CUA TÔM CÁ-Bùi Đức Minh Quang";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private ComboBox chon;
        private Label label2;
        private ComboBox tienCuoc;
        private Button button1;
        private GroupBox groupBox1;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private Label TienHienTai;
        private GroupBox groupBox2;
        private Label label4;
        private Label label3;
        private Label label5;
        private Label label6;
        private Label label7;
        private PictureBox pictureBox4;
        private CheckBox cb_ca;
        private CheckBox cb_cua;
        private CheckBox cb_tom;
        private CheckBox cb_ga;
        private CheckBox cb_bau;
        private CheckBox cb_nai;
        private Button naptien;
        private CheckBox checkBox7;
        private Button button2;
        private Button button4;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Button button5;
        private ListBox listBox1;
        private Label label8;
    }
}